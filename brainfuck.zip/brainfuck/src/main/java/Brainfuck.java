import javax.tools.JavaCompiler;
import java.util.*;
public class Brainfuck {

    private static Scanner ob = new Scanner(System.in);

    public static void interpret(String program) {
         List <Command> compiledProgram = new Compiler().compile(program);
        compiledProgram.stream().forEach((commandTemp) -> System.out.println(commandTemp));
         new Executor().execute(compiledProgram);
    }
    public static void main(String args[])
    {
        System.out.println("Enter the code:");
        String code = ob.nextLine();
        System.out.println("Output:");
        interpret(code);
    }
}
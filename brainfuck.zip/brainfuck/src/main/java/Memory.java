public class Memory {
    public static int ptr; // Data pointer

    // Max memory limit. It is the highest number which
    // can be represented by an unsigned 16-bit binary
    // number. Many computer programming environments
    // beside brainfuck may have predefined
    // constant values representing 65535.
    public static int length = 65535;
    int c = 0;

    // Array of byte type simulating memory of max
    // 65535 bits from 0 to 65534.
    public static byte memory[] = new byte[length];
}

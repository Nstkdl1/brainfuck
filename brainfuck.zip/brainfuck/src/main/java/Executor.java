import java.util.List;

public class Executor {
    public void execute(List<Command> temp) {
        Memory memory = new Memory();
        temp.stream().forEach((commandTemp) -> commandTemp.execute(memory));
//        temp.stream().forEach((commandTemp) -> System.out.println(commandTemp));
    }

}

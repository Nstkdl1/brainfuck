public interface Command {

    void execute (Memory memory);

}

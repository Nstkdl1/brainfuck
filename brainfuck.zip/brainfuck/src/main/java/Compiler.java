import java.util.ArrayList;
import java.util.List;

public class Compiler {
    public static List <Command> temp=new ArrayList<Command>();

    public static Command moveRight=new Command() {
        @Override
        public void execute(Memory memory) {
            if (memory.ptr == memory.length - 1)
                memory.ptr = 0;
            else
                memory.ptr ++;
        }
    };

    public static Command moveLeft=new Command() {
        @Override
        public void execute(Memory memory) {
            if (memory.ptr == 0)
                memory.ptr = memory.length - 1;
            else
                memory.ptr --;
        }
    };

    public static Command Increment=new Command() {
        @Override
        public void execute(Memory memory) {
            memory.memory[memory.ptr]++;
        }
    };
    public static Command Decrement=new Command() {
        @Override
        public void execute(Memory memory) {
            memory.memory[memory.ptr] --;
        }
    };
    public static Command Print=new Command() {
        @Override
        public void execute(Memory memory) {
            System.out.print((char)(memory.memory[memory.ptr]));
        }
    };

    public static List<Command> compile(String text) {
        System.out.println("String is: " + text);
        for (int i = 0; i < text.length(); i++) {

            if (text.charAt(i) == '>')
            {
                temp.add(moveRight);
            }
            else if (text.charAt(i) == '<')
            {
                temp.add(moveLeft);
            }
            else if (text.charAt(i) == '+')
                temp.add(Increment);

            else if (text.charAt(i) == '-')
                temp.add(Decrement);

            else if (text.charAt(i) == '.')
                temp.add(Print);

            else if (text.charAt(i) == '[')
            {
                // IDK HOW TO DO LOOPS HERE
            }
        }
        return temp;
        };
    }
